# Connect Four

This private repository contains the original Pygame source and a browser-compatible version. The public game is at <https://rehanmohammed2609.github.io/connect4/>.

## Play

- Move the mouse over the board to aim.
- Click a column to drop a piece.
- Or use **Left/Right** to select a column and **Space/Enter** to drop.
- Players take turns: Player 1 is red; Player 2 is yellow.
- Connect four pieces horizontally, vertically, or diagonally to win.
- After a win or a draw, click to start a new game.

The original NumPy-based Pygame source is preserved as `legacy/connect4.py`. The browser entry point uses a built-in Python list for the board, so NumPy is not required.

## Run locally

Use Python 3.11 and install the dependencies:

```sh
python -m pip install -r requirements.txt
python main.py
```

## Build and test in a browser

```sh
python -m pygbag --build --app_name "Connect Four" --title "Connect Four" --package "connect4" .
python .github/scripts/patch_pygbag_output.py
python -m http.server 8000 --directory build/web
```

Open <http://localhost:8000> in a modern browser.
The browser page scales the square game canvas to fit the available viewport so the full six-row board remains visible.
