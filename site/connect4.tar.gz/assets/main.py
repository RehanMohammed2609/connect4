import asyncio

import pygame


ROW_COUNT = 6
COLUMN_COUNT = 7
SQUARE_SIZE = 100
WIDTH = COLUMN_COUNT * SQUARE_SIZE
HEIGHT = (ROW_COUNT + 1) * SQUARE_SIZE
RADIUS = SQUARE_SIZE // 2 - 5

BLUE = (0, 0, 255)
BLACK = (0, 0, 0)
RED = (255, 0, 0)
YELLOW = (255, 255, 0)
WHITE = (255, 255, 255)


def create_board():
    return [[0 for _ in range(COLUMN_COUNT)] for _ in range(ROW_COUNT)]


def is_valid_location(board, col):
    return 0 <= col < COLUMN_COUNT and board[0][col] == 0


def get_next_open_row(board, col):
    for row in range(ROW_COUNT - 1, -1, -1):
        if board[row][col] == 0:
            return row
    return None


def drop_piece(board, row, col, piece):
    board[row][col] = piece


def winning_move(board, piece):
    directions = ((0, 1), (1, 0), (1, 1), (-1, 1))
    for row in range(ROW_COUNT):
        for col in range(COLUMN_COUNT):
            for row_step, col_step in directions:
                end_row = row + row_step * 3
                end_col = col + col_step * 3
                if not (0 <= end_row < ROW_COUNT and 0 <= end_col < COLUMN_COUNT):
                    continue
                if all(
                    board[row + row_step * offset][col + col_step * offset] == piece
                    for offset in range(4)
                ):
                    return True
    return False


def play_column(board, col, turn):
    if not is_valid_location(board, col):
        return turn, 0, False

    row = get_next_open_row(board, col)
    if row is None:
        return turn, 0, False

    piece = turn + 1
    drop_piece(board, row, col, piece)
    if winning_move(board, piece):
        return turn, piece, True
    if all(board[0][column] != 0 for column in range(COLUMN_COUNT)):
        return turn, 0, True
    return 1 - turn, 0, False


def draw_board(screen, board, turn, mouse_x, selected_col, game_over, winner, status_font):
    screen.fill(BLACK)

    if not game_over:
        preview_color = RED if turn == 0 else YELLOW
        preview_x = (
            mouse_x
            if 0 <= mouse_x < WIDTH
            else selected_col * SQUARE_SIZE + SQUARE_SIZE // 2
        )
        pygame.draw.circle(screen, preview_color, (preview_x, SQUARE_SIZE // 2), RADIUS)

    for col in range(COLUMN_COUNT):
        for row in range(ROW_COUNT):
            x = col * SQUARE_SIZE
            y = (row + 1) * SQUARE_SIZE
            pygame.draw.rect(screen, BLUE, (x, y, SQUARE_SIZE, SQUARE_SIZE))
            pygame.draw.circle(
                screen,
                BLACK,
                (x + SQUARE_SIZE // 2, y + SQUARE_SIZE // 2),
                RADIUS,
            )

            piece = board[row][col]
            if piece:
                color = RED if piece == 1 else YELLOW
                center = (
                    x + SQUARE_SIZE // 2,
                    (row + 1) * SQUARE_SIZE + SQUARE_SIZE // 2,
                )
                pygame.draw.circle(screen, color, center, RADIUS)

    if winner:
        message = f"Player {winner} wins! Click to play again"
        color = RED if winner == 1 else YELLOW
    elif game_over:
        message = "Draw! Click to play again"
        color = WHITE
    else:
        player = turn + 1
        message = f"Player {player}'s turn"
        color = RED if turn == 0 else YELLOW

    label = status_font.render(message, True, color)
    screen.blit(label, label.get_rect(center=(WIDTH // 2, SQUARE_SIZE // 2)))
    pygame.display.flip()


async def main():
    pygame.init()
    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    pygame.display.set_caption("Connect Four")
    status_font = pygame.font.SysFont("monospace", 30)
    clock = pygame.time.Clock()

    board = create_board()
    turn = 0
    game_over = False
    winner = 0
    mouse_x = -1
    selected_col = COLUMN_COUNT // 2
    running = True

    while running:
        await asyncio.sleep(0)
        clock.tick(60)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEMOTION:
                mouse_x = event.pos[0]
                if 0 <= mouse_x < WIDTH:
                    selected_col = mouse_x // SQUARE_SIZE
            elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                if game_over:
                    board = create_board()
                    turn = 0
                    game_over = False
                    winner = 0
                else:
                    col = event.pos[0] // SQUARE_SIZE
                    turn, winner, game_over = play_column(board, col, turn)
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_LEFT:
                    selected_col = max(0, selected_col - 1)
                    mouse_x = -1
                elif event.key == pygame.K_RIGHT:
                    selected_col = min(COLUMN_COUNT - 1, selected_col + 1)
                    mouse_x = -1
                elif event.key in (pygame.K_SPACE, pygame.K_RETURN) and not game_over:
                    turn, winner, game_over = play_column(board, selected_col, turn)
                    mouse_x = -1

        draw_board(
            screen,
            board,
            turn,
            mouse_x,
            selected_col,
            game_over,
            winner,
            status_font,
        )


asyncio.run(main())
